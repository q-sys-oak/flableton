# FLABLETON Bridge

FLABLETON Bridge is a small desktop helper that lets FLABLETON, which runs in your browser, use the **VST3 plugins installed on your computer**, with their own plugin windows. Browsers can't load VST plugins themselves, so the Bridge hosts them and streams their audio to FLABLETON on the same machine.

## Use it

1. Download the Bridge for your computer (Windows `.exe` or Mac) and open it. Leave its window open.
   - **Mac:** the first time, right-click the file and choose **Open** (the app isn't signed yet).
   - **Windows:** if SmartScreen appears, click **More info → Run anyway**.
2. Open FLABLETON in **Chrome or Edge** and press **Connect** under **VST** in the left panel. If Chrome asks whether this site may use apps on your device, choose **Allow**.
3. Click a plugin to add it: instruments become a new channel, effects go on the selected track. Press **🪟 Open plugin window** for the plugin's own controls.

Plugins are found in the standard VST3 folders:

| OS | Folders |
| --- | --- |
| Windows | `C:\Program Files\Common Files\VST3`, `%LOCALAPPDATA%\Programs\Common\VST3` |
| Mac | `/Library/Audio/Plug-Ins/VST3`, `~/Library/Audio/Plug-Ins/VST3` |
| Linux | `~/.vst3`, `/usr/lib/vst3`, `/usr/local/lib/vst3` |

Add more folders with `--plugin-folder PATH`.

## How it works

- **Scanning:** each plugin is loaded in a separate process during the scan, so a plugin that crashes on load can't take the Bridge down.
- **Fixed delay:** audio runs in 128-sample blocks with a fixed four-block (about 11 ms) delay.
  - FLABLETON sends notes to instruments early by exactly that delay, so they land on the beat.
  - Effects report the delay, and the mixer lines every other track up with them (plugin delay compensation).
- **Security:** the Bridge only listens on `127.0.0.1` (never the network) and only accepts connections from FLABLETON's own web addresses.
- **Saved state:** each plugin's own state (its presets and settings) is saved inside the FLABLETON project.
- **Export:** songs that use VST plugins export in real time.

## Build it

The Bridge uses the [Steinberg VST3 SDK](https://github.com/steinbergmedia/vst3sdk) (MIT license); CMake fetches it automatically.

```bash
cmake -S bridge -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

To test against real plugins, see `.github/workflows/bridge.yml`: it builds Steinberg's sample plugins and runs `test/protocol.test.mjs`.

## Protocol (WebSocket on port 47820)

Control messages are JSON text frames: `{ "op": ..., "req": n, ... }`. The reply echoes `req`, or carries `"op": "error"` with a `message`.

| op | Arguments | Reply |
| --- | --- | --- |
| `hello` | | `bridge`, `protocol`, `os`, `editors` |
| `scan` | `rescan` | `plugins: [{uid, name, vendor, version, category, path, kind}]` |
| `load` | `uid, path, sampleRate, maxBlock, state?` | `id, name, kind, inputs, outputs, latency, editor, params[]` |
| `setParam` | `id, param, value` (0..1) | none (fire and forget) |
| `getState` / `setState` | `id` / `id, state` (base64) | `state` / `params` |
| `openEditor` / `closeEditor` | `id` | `editorOpened` / `editorClosed` |
| `unload` | `id` | `unloaded` |

Events sent from the Bridge: `{op: "param", id, param, value}` when the plugin's own window changes a control, and `{op: "latency", id, samples}`.

Audio uses binary frames, little-endian.

Request:

| Field | Type |
| --- | --- |
| type = 1 | `u8` |
| version = 1 | `u8` |
| event count | `u16` |
| instance id | `u32` |
| sequence number | `u32` |
| frames | `u32` |
| input channels | `u16` |
| flags (bit 0 = playing) | `u16` |
| tempo | `f32` |
| position in quarter notes | `f64` |
| events | `{u32 offset, u8 status, u8 d1, u8 d2, u8 pad}` for each event |
| audio | `f32` input samples, one channel after another |

Reply:

| Field | Type |
| --- | --- |
| type = 2 | `u8` |
| version = 1 | `u8` |
| output channels | `u16` |
| instance id | `u32` |
| sequence number | `u32` |
| frames | `u32` |
| audio | `f32` output samples, one channel after another |
